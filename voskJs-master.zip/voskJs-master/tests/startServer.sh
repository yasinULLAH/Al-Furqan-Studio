#!/bin/bash 
node voskjshttp --model=../models/vosk-model-small-en-us-0.15
