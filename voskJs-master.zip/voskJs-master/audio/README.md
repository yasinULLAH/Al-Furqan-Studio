# Audio files

The repo contains few English language speech audio files, coming from Mozilla Deespeech repo.
Useful to make some tests and comparisons. 
Source: https://github.com/mozilla/DeepSpeech/releases/download/v0.9.3/audio-0.9.3.tar.gz

| speech file          | text                            |
| ------------------   | ------------------------        |
| 2830-3980-0043.wav   | experience proves this          |
| 4507-16021-0012.wav  | why should one hold on the way  |
| 8455-210777-0068.wav | your power is sufficient i said |

---

[top](#) | [home](../README.md)
